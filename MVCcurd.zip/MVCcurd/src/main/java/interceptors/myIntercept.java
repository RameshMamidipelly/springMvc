package interceptors;

import org.springframework.web.servlet.HandlerInterceptor;

public class myIntercept implements HandlerInterceptor {

}
